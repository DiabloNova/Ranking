import Link from 'next/link'

export function Footer() {
  return (
    <footer className="neumorphic-light mt-20 mx-4 sm:mx-6 lg:mx-8 mb-4 rounded-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-2xl">📈</span>
              رنکینگ
            </h3>
            <p className="text-muted text-sm">متخصصان بهینه‌سازی موتورهای جستجو</p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">محصولات</h4>
            <ul className="space-y-2 text-muted">
              <li>
                <Link href="/analyzer" className="hover:text-primary transition-colors">
                  ابزار تحلیل رایگان
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-primary transition-colors">
                  پنل کاربری
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">شرکت</h4>
            <ul className="space-y-2 text-muted">
              <li>
                <Link href="/about" className="hover:text-primary transition-colors">
                  درباره ما
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary transition-colors">
                  تماس با ما
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">حقوقی</h4>
            <ul className="space-y-2 text-muted">
              <li>
                <Link href="/terms" className="hover:text-primary transition-colors">
                  شرایط استفاده
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-primary transition-colors">
                  سیاست حریم خصوصی
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-8">
          <p className="text-center text-muted">
            © ۲۰۲۶ رنکینگ. تمام حقوق محفوظ است.
          </p>
        </div>
      </div>
    </footer>
  )
}
