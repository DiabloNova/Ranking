'use client'

import Link from 'next/link'
import { useSession } from '@/lib/auth-client'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'
import { Menu, X } from 'lucide-react'
import { useState } from 'react'

export function Navbar() {
  const { data: session, isPending } = useSession()
  const router = useRouter()
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleLogout = async () => {
    await authClient.signOut()
    router.push('/')
    router.refresh()
  }

  return (
    <nav className="sticky top-0 z-50 bg-gray-200 backdrop-blur-md border-b border-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 font-bold text-2xl text-primary">
            <span className="text-3xl">📈</span>
            رنکینگ
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8 items-center">
            <Link href="/" className="text-foreground hover:text-primary transition-colors">
              خانه
            </Link>
            <Link href="/about" className="text-foreground hover:text-primary transition-colors">
              درباره ما
            </Link>
            <Link href="/analyzer" className="text-foreground hover:text-primary transition-colors">
              ابزار تحلیل
            </Link>
            <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
              تماس با ما
            </Link>

            {!isPending && (
              <>
                {session?.user ? (
                  <div className="flex gap-4 items-center">
                    <Link
                      href="/dashboard"
                      className="px-4 py-2 neumorphic-light rounded-lg text-sm font-medium hover:shadow-xl transition-all"
                    >
                      پنل کاربری
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-all"
                    >
                      خروج
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-3">
                    <Link
                      href="/sign-in"
                      className="px-4 py-2 text-primary font-medium hover:bg-primary/10 rounded-lg transition-colors"
                    >
                      ورود
                    </Link>
                    <Link
                      href="/sign-up"
                      className="px-6 py-2 bg-primary text-white rounded-full font-medium hover:shadow-lg transition-all"
                    >
                      ثبت‌نام
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 hover:bg-primary/10 rounded-lg transition-colors"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden pb-4 border-t border-primary/10 flex flex-col gap-3">
            <Link href="/" className="px-4 py-2 hover:bg-primary/10 rounded-lg transition-colors">
              خانه
            </Link>
            <Link href="/about" className="px-4 py-2 hover:bg-primary/10 rounded-lg transition-colors">
              درباره ما
            </Link>
            <Link href="/analyzer" className="px-4 py-2 hover:bg-primary/10 rounded-lg transition-colors">
              ابزار تحلیل
            </Link>
            <Link href="/contact" className="px-4 py-2 hover:bg-primary/10 rounded-lg transition-colors">
              تماس با ما
            </Link>

            {!isPending && (
              <>
                {session?.user ? (
                  <>
                    <Link
                      href="/dashboard"
                      className="px-4 py-2 neumorphic-light rounded-lg text-sm font-medium"
                    >
                      پنل کاربری
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium"
                    >
                      خروج
                    </button>
                  </>
                ) : (
                  <>
                    <Link href="/sign-in" className="px-4 py-2 text-primary font-medium">
                      ورود
                    </Link>
                    <Link
                      href="/sign-up"
                      className="px-6 py-2 bg-primary text-white rounded-full font-medium"
                    >
                      ثبت‌نام
                    </Link>
                  </>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  )
}
