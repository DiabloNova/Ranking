'use client'

import { useState } from 'react'
import { Mail, Phone, MapPin } from 'lucide-react'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, send to backend
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
    setFormData({ name: '', email: '', phone: '', message: '' })
  }

  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-black text-foreground mb-4">تماس با ما</h1>
          <p className="text-xl text-muted font-medium max-w-2xl mx-auto">
            سؤالی دارید؟ ما اینجا هستیم تا کمک کنیم
          </p>
        </div>
      </section>

      {/* Content Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <h2 className="text-3xl font-black text-foreground">اطلاعات تماس</h2>

            <div className="neumorphic-card p-6 flex gap-4">
              <div className="text-primary text-2xl">
                <Mail size={32} />
              </div>
              <div>
                <h3 className="font-bold text-foreground mb-1">ایمیل</h3>
                <p className="text-muted">info@ranking.ir</p>
              </div>
            </div>

            <div className="neumorphic-card p-6 flex gap-4">
              <div className="text-primary text-2xl">
                <Phone size={32} />
              </div>
              <div>
                <h3 className="font-bold text-foreground mb-1">تلفن</h3>
                <p className="text-muted">۰۲۱-۹۱۲۱۲۳۴۵</p>
              </div>
            </div>

            <div className="neumorphic-card p-6 flex gap-4">
              <div className="text-primary text-2xl">
                <MapPin size={32} />
              </div>
              <div>
                <h3 className="font-bold text-foreground mb-1">آدرس</h3>
                <p className="text-muted">تهران، خیابان فلسطین</p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <div className="neumorphic-card p-8">
              <h2 className="text-3xl font-black text-foreground mb-6">فرم تماس</h2>

              {submitted && (
                <div className="mb-6 p-4 bg-green-100 text-green-800 rounded-lg text-center font-medium">
                  ✓ پیام شما با موفقیت ارسال شد
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">نام</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="نام خود را وارد کنید"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">ایمیل</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="ایمیل خود را وارد کنید"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">تلفن</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="تلفن خود را وارد کنید"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">پیام</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    placeholder="پیام خود را بنویسید"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary text-white rounded-lg font-bold hover:bg-primary/90 transition-all neumorphic-light"
                >
                  ارسال پیام
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
