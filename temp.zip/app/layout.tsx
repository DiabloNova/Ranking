import type { Metadata, Viewport } from 'next'
import './globals.css'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'

export const metadata: Metadata = {
  title: 'رنکینگ | خدمات بهینه‌سازی SEO متخصصانه',
  description: 'افزایش رتبه‌بندی سایت شما در گوگل با خدمات SEO متخصصانه رنکینگ. ترافیک ارگانیک، تحلیل جامع و مشاوره رایگان.',
  keywords: 'SEO, بهینه‌سازی موتور جستجو, گوگل, رتبه‌بندی سایت, ترافیک ارگانیک',
  authors: [{ name: 'رنکینگ' }],
  creator: 'رنکینگ',
  publisher: 'رنکینگ',
  alternates: {
    canonical: 'https://ranking.ir',
  },
  openGraph: {
    type: 'website',
    locale: 'fa_IR',
    url: 'https://ranking.ir',
    siteName: 'رنکینگ',
    title: 'رنکینگ | خدمات بهینه‌سازی SEO',
    description: 'افزایش رتبه‌بندی سایت شما در گوگل با خدمات SEO متخصصانه',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  userScalable: true,
  themeColor: '#FF5555',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'رنکینگ',
    url: 'https://ranking.ir',
    logo: 'https://ranking.ir/logo.png',
    description: 'خدمات بهینه‌سازی موتورهای جستجو و ترافیک ارگانیک',
    contact: {
      '@type': 'ContactPoint',
      telephone: '+98-21-91212345',
      contactType: 'Customer Service',
    },
    sameAs: [
      'https://instagram.com/ranking_seo',
      'https://t.me/ranking_seo',
    ],
  }

  return (
    <html lang="fa" dir="rtl" className="bg-background">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <link rel="sitemap" href="/sitemap.xml" />
        <link rel="canonical" href="https://ranking.ir" />
      </head>
      <body className="antialiased font-sans bg-background text-foreground min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
