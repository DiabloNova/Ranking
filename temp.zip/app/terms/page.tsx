export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-soft py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-black text-foreground mb-8">شرایط استفاده</h1>
        
        <div className="neumorphic-card space-y-6">
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">۱. تعریف خدمات</h2>
            <p className="text-muted leading-relaxed">
              خدمات رنکینگ شامل تجزیه‌وتحلیل وب‌سایت، مشاوره SEO و گزارش‌های پیشرفت است. ما تمام سعی خود را می‌کنیم درقبال رقابت‌پذیری سایت کار کنیم.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">۲. مسئولیت کاربر</h2>
            <p className="text-muted leading-relaxed">
              کاربران مسئول محتوای خود هستند. تنها از روش‌های سفید کلاه SEO استفاده کنید. تخلف از این شرایط موجب لغو حساب خواهد شد.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">۳. محدودیت مسئولیت</h2>
            <p className="text-muted leading-relaxed">
              رنکینگ تضمین نمی‌دهد که سایت شما دقیقاً در رتبه‌ی مطلوب قرار خواهد گرفت. نتایج بستگی به عوامل متعددی دارد که خارج از کنترل ما هستند.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">۴. تغییرات شرایط</h2>
            <p className="text-muted leading-relaxed">
              رنکینگ حق دارد این شرایط را در هر زمانی تغییر دهد. استفاده مداوم از سرویس به معنی پذیرش شرایط جدید است.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">۵. تماس با ما</h2>
            <p className="text-muted leading-relaxed">
              برای هرگونه سؤال درباره این شرایط، لطفاً با ما تماس بگیرید: info@ranking.ir
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
