import { Target, Users, Zap } from 'lucide-react'

export const metadata = {
  title: 'درباره رنکینگ - تیم متخصص بهینه‌سازی موتورهای جستجو',
  description: 'رنکینگ تیمی از متخصصان SEO با بیش از ۱۰ سال تجربه. ما کمک می‌کنیم کسب‌وکارهای شما در نتایج گوگل رتبه‌های بالاتری پیدا کنند.',
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-black text-foreground mb-4">درباره رنکینگ</h1>
          <p className="text-xl text-muted font-medium max-w-2xl mx-auto">
            متخصصان SEO با بیش از ۱۰ سال تجربه و ۲۹۹+ پروژه موفق
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="neumorphic-card p-12 mb-12">
          <h2 className="text-4xl font-black text-foreground mb-6">داستان ما</h2>
          <p className="text-lg text-muted font-medium leading-relaxed mb-4">
            رنکینگ در سال ۱۴۰۰ تأسیس شد تا کسب‌وکارهای کوچک و بزرگ را در بهینه‌سازی موتورهای جستجو کمک کند.
            ما باور داریم که هر کسب‌وکار شایسته است دید بیشتری در جستجوهای آنلاین داشته باشد.
          </p>
          <p className="text-lg text-muted font-medium leading-relaxed">
            تیم ما متشکل از متخصصین SEO، برنامه‌نویسان و تحلیلگران است که مشتاق کمک به شما در دستیابی به
            اهداف دیجیتالی‌تان هستند. ما از روش‌های سفید کلاه و استراتژی‌های داده‌محور استفاده می‌کنیم.
          </p>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="neumorphic-card p-8">
            <div className="flex items-center gap-3 mb-4">
              <Target className="text-primary" size={32} />
              <h3 className="text-2xl font-black text-foreground">ماموریت</h3>
            </div>
            <p className="text-muted font-medium">
              کمک به کسب‌وکارها برای دستیابی به رتبه‌های بالاتر در گوگل و افزایش ترافیک آنلاین
            </p>
          </div>

          <div className="neumorphic-card p-8">
            <div className="flex items-center gap-3 mb-4">
              <Target className="text-primary" size={32} />
              <h3 className="text-2xl font-black text-foreground">ماموریت</h3>
            </div>
            <p className="text-muted font-medium">
              کمک به کسب‌وکارها برای دستیابی به رتبه‌های بالاتر در گوگل و افزایش ترافیک آنلاین
            </p>
          </div>

          <div className="neumorphic-card p-8">
            <div className="flex items-center gap-3 mb-4">
              <Users className="text-primary" size={32} />
              <h3 className="text-2xl font-black text-foreground">ارزش‌ها</h3>
            </div>
            <p className="text-muted font-medium">
              شفافیت، نوآوری، تعهد به نتایج و رضایت مشتری
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black text-foreground mb-4">تیم ما</h2>
          <p className="text-lg text-muted font-medium">
            متخصصین مجرب در زمینه‌های مختلف SEO
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {[
            { name: 'علی محمدی', role: 'مدیر اجرایی' },
            { name: 'فاطمه احمدی', role: 'متخصص SEO' },
            { name: 'محمد حسینی', role: 'توسعه‌دهنده' },
            { name: 'سارا رضایی', role: 'تحلیلگر داده' },
          ].map((member, i) => (
            <div key={i} className="glassmorphic p-6 rounded-2xl text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">👤</span>
              </div>
              <h3 className="font-bold text-foreground mb-1">{member.name}</h3>
              <p className="text-muted font-medium text-sm">{member.role}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { number: '۵۰۰+', label: 'مشتری راضی' },
            { number: '۱۰+', label: 'سال تجربه' },
            { number: '۱۵۰۰+', label: 'پروژه انجام‌شده' },
            { number: '۹۸%', label: 'نرخ موفقیت' },
          ].map((stat, i) => (
            <div key={i} className="neumorphic-light p-8 rounded-2xl text-center">
              <p className="text-4xl font-black text-primary mb-2">{stat.number}</p>
              <p className="text-muted font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
