'use client'

import { useEffect, useState } from 'react'
import { redirect } from 'next/navigation'
import { useSession } from '@/lib/auth-client'
import { getAnalysisHistory, deleteAnalysis, analyzeWebsite } from '@/app/actions/seo'
import { Trash2, Plus, Loader } from 'lucide-react'

export default function DashboardPage() {
  const { data: session, isPending } = useSession()
  const [analyses, setAnalyses] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [url, setUrl] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isPending && !session?.user) {
      redirect('/sign-in')
    }
  }, [session, isPending])

  useEffect(() => {
    if (session?.user) {
      loadAnalyses()
    }
  }, [session?.user])

  const loadAnalyses = async () => {
    try {
      setLoading(true)
      const data = await getAnalysisHistory()
      setAnalyses(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در بارگذاری داده')
    } finally {
      setLoading(false)
    }
  }

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault()
    setAnalyzing(true)
    setError('')

    try {
      const result = await analyzeWebsite(url)
      setAnalyses([result, ...analyses])
      setUrl('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در تجزیه')
    } finally {
      setAnalyzing(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await deleteAnalysis(id)
      setAnalyses(analyses.filter((a) => a.id !== id))
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در حذف')
    }
  }

  if (isPending) {
    return (
      <div className="min-h-screen bg-gradient-soft flex items-center justify-center">
        <Loader className="animate-spin text-primary" size={40} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-soft py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-black text-foreground mb-2">
            خوش آمدید، {session?.user?.name || 'کاربر'}!
          </h1>
          <p className="text-lg text-muted font-medium">مدیریت تجزیه‌های شما و سابقه SEO</p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="glassmorphic p-4 rounded-2xl border border-red-200 mb-8">
            <p className="text-red-600 font-medium">{error}</p>
          </div>
        )}

        {/* Quick Analyze Section */}
        <div className="glassmorphic p-8 rounded-3xl neumorphic-light mb-12">
          <h2 className="text-2xl font-black text-foreground mb-4">تجزیه‌ی جدید</h2>
          <form onSubmit={handleAnalyze} className="space-y-4">
            <div className="flex gap-2 flex-col sm:flex-row">
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className="flex-1 px-4 py-3 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-medium"
                required
              />
              <button
                type="submit"
                disabled={analyzing}
                className="px-6 py-3 bg-primary text-white rounded-lg font-bold hover:bg-primary/90 disabled:opacity-50 transition-all flex items-center gap-2"
              >
                <Plus size={20} />
                {analyzing ? 'درحال تجزیه...' : 'تجزیه'}
              </button>
            </div>
          </form>
        </div>

        {/* Analysis History */}
        <div className="mb-12">
          <h2 className="text-3xl font-black text-foreground mb-6">تاریخچه تجزیه‌ها</h2>

          {loading ? (
            <div className="flex justify-center py-12">
              <Loader className="animate-spin text-primary" size={40} />
            </div>
          ) : analyses.length === 0 ? (
            <div className="glassmorphic p-12 rounded-3xl text-center">
              <p className="text-lg text-muted font-medium mb-4">هنوز تجزیه‌ای انجام نشده‌است</p>
              <p className="text-muted font-medium">وب‌سایت خود را تجزیه کنید تا نتایج را ببینید</p>
            </div>
          ) : (
            <div className="grid gap-6">
              {analyses.map((analysis) => (
                <div
                  key={analysis.id}
                  className="glassmorphic p-6 rounded-2xl neumorphic-light hover:shadow-xl transition-all"
                >
                  <div className="flex items-start justify-between gap-6 flex-col sm:flex-row">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-foreground mb-2">
                        {analysis.title || 'بدون عنوان'}
                      </h3>
                      <p className="text-muted font-medium mb-3">{analysis.website}</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                        <div>
                          <p className="text-muted font-medium">H1</p>
                          <p className="font-bold text-foreground">{analysis.headings?.h1 || 0}</p>
                        </div>
                        <div>
                          <p className="text-muted font-medium">SSL</p>
                          <p className="font-bold text-foreground">
                            {analysis.sslCertificate ? '✓' : '✗'}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted font-medium">موبایل</p>
                          <p className="font-bold text-foreground">
                            {analysis.mobileReady ? '✓' : '✗'}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted font-medium">تاریخ</p>
                          <p className="font-bold text-foreground">
                            {new Date(analysis.createdAt).toLocaleDateString('fa-IR')}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div
                          className={`w-20 h-20 rounded-full flex items-center justify-center text-2xl font-black ${
                            analysis.score >= 80
                              ? 'bg-green-100 text-green-700'
                              : analysis.score >= 60
                                ? 'bg-yellow-100 text-yellow-700'
                                : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {Math.round(analysis.score)}
                        </div>
                      </div>

                      <button
                        onClick={() => handleDelete(analysis.id)}
                        className="p-2 hover:bg-red-100 text-red-500 rounded-lg transition-colors"
                        title="حذف"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Stats Section */}
        {analyses.length > 0 && (
          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                label: 'کل تجزیه‌ها',
                value: analyses.length,
                icon: '📊',
              },
              {
                label: 'میانگین امتیاز',
                value:
                  Math.round(
                    analyses.reduce((sum, a) => sum + a.score, 0) / analyses.length
                  ) || 0,
                icon: '⭐',
              },
              {
                label: 'سایت‌های آماده موبایل',
                value: analyses.filter((a) => a.mobileReady).length,
                icon: '📱',
              },
              {
                label: 'سایت‌های SSL دار',
                value: analyses.filter((a) => a.sslCertificate).length,
                icon: '🔒',
              },
            ].map((stat, i) => (
              <div key={i} className="neumorphic-light p-6 rounded-2xl text-center">
                <p className="text-3xl mb-2">{stat.icon}</p>
                <p className="text-2xl font-black text-primary mb-1">{stat.value}</p>
                <p className="text-muted font-medium text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
