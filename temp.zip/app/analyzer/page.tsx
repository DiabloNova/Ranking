'use client'

import { useState } from 'react'
import { Loader, CheckCircle, AlertCircle } from 'lucide-react'

export default function AnalyzerPage() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setResult(null)

    try {
      // Validate URL
      let parsedUrl: URL
      try {
        parsedUrl = new URL(url)
      } catch {
        throw new Error('URL نامعتبر است. لطفاً URL معتبری وارد کنید.')
      }

      // Fetch and parse website
      const response = await fetch(url, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
      })

      if (!response.ok) {
        throw new Error('نمی‌تواند وب‌سایت را بارگذاری کند')
      }

      const htmlContent = await response.text()

      // Parse HTML (client-side simulation)
      const parser = new DOMParser()
      const doc = parser.parseFromString(htmlContent, 'text/html')

      // Extract metadata
      const title = doc.querySelector('title')?.textContent || ''
      const metaDescription =
        doc.querySelector('meta[name="description"]')?.getAttribute('content') || ''
      const h1Count = doc.querySelectorAll('h1').length
      const h2Count = doc.querySelectorAll('h2').length
      const images = doc.querySelectorAll('img')
      const hasSsl = parsedUrl.protocol === 'https:'
      const viewportMeta = doc.querySelector('meta[name="viewport"]')
      const isMobileReady = !!viewportMeta

      // Calculate score
      let score = 50
      if (title.length > 0) score += 5
      if (title.length >= 30 && title.length <= 60) score += 5
      if (metaDescription.length > 0) score += 5
      if (metaDescription.length >= 120 && metaDescription.length <= 160) score += 5
      if (h1Count === 1) score += 5
      if (h2Count > 0) score += 5
      if (hasSsl) score += 5
      if (isMobileReady) score += 5

      const analysis = {
        url,
        title: title || 'عنوان یافت نشد',
        description: metaDescription || 'توضیح یافت نشد',
        h1Count,
        h2Count,
        imageCount: images.length,
        hasSsl,
        isMobileReady,
        score: Math.min(100, score),
      }

      setResult(analysis)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطای نامشخص')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-soft py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-black text-foreground mb-4">
            تجزیه‌گر SEO رایگان
          </h1>
          <p className="text-xl text-muted font-medium">
            وب‌سایت خود را تجزیه کنید و نکات بهبود را پیدا کنید
          </p>
        </div>

        {/* Input Section */}
        <div className="glassmorphic p-8 rounded-3xl neumorphic-light mb-8">
          <form onSubmit={handleAnalyze} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                آدرس وب‌سایت
              </label>
              <div className="flex gap-2 flex-col sm:flex-row">
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com"
                  className="flex-1 px-4 py-3 bg-white border border-primary/20 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-medium"
                  required
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="px-8 py-3 bg-primary text-white rounded-lg font-bold hover:bg-primary/90 disabled:opacity-50 transition-all"
                >
                  {loading ? 'درحال تحلیل...' : 'تجزیه کنید'}
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Loading */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="text-center">
              <Loader className="animate-spin text-primary mx-auto mb-4" size={40} />
              <p className="text-muted font-medium">درحال تجزیه وب‌سایت...</p>
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="glassmorphic p-6 rounded-2xl border border-red-200 mb-8">
            <div className="flex gap-3 items-start">
              <AlertCircle className="text-red-500 flex-shrink-0 mt-1" size={24} />
              <div>
                <h3 className="font-bold text-red-700 mb-1">خطا</h3>
                <p className="text-red-600">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Overall Score */}
            <div className="glassmorphic p-8 rounded-3xl neumorphic-light">
              <div className="flex items-center justify-between gap-8 flex-col sm:flex-row">
                <div>
                  <h2 className="text-3xl font-black text-foreground mb-2">نمرات SEO</h2>
                  <p className="text-muted font-medium">{result.url}</p>
                </div>
                <div className="text-center">
                  <div
                    className={`w-32 h-32 rounded-full flex items-center justify-center text-4xl font-black ${
                      result.score >= 80
                        ? 'bg-green-100 text-green-700'
                        : result.score >= 60
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-red-100 text-red-700'
                    }`}
                  >
                    {result.score}
                  </div>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="grid md:grid-cols-2 gap-6">
              {[
                {
                  label: 'عنوان صفحه',
                  value: result.title,
                  icon: '📝',
                  status: result.title ? 'success' : 'warning',
                },
                {
                  label: 'توضیح فراداده',
                  value: result.description || 'تعریف نشده',
                  icon: '📄',
                  status: result.description ? 'success' : 'warning',
                },
                {
                  label: 'تعداد H1',
                  value: result.h1Count,
                  icon: '🎯',
                  status: result.h1Count === 1 ? 'success' : 'warning',
                },
                {
                  label: 'تعداد H2',
                  value: result.h2Count,
                  icon: '📊',
                  status: result.h2Count > 0 ? 'success' : 'warning',
                },
                {
                  label: 'گواهی SSL',
                  value: result.hasSsl ? 'فعال' : 'غیرفعال',
                  icon: '🔒',
                  status: result.hasSsl ? 'success' : 'error',
                },
                {
                  label: 'تجاوب موبایل',
                  value: result.isMobileReady ? 'آماده' : 'آماده نیست',
                  icon: '📱',
                  status: result.isMobileReady ? 'success' : 'warning',
                },
              ].map((item, i) => (
                <div key={i} className="glassmorphic p-6 rounded-2xl">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-foreground flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      {item.label}
                    </h3>
                    {item.status === 'success' ? (
                      <CheckCircle className="text-green-500" size={20} />
                    ) : item.status === 'warning' ? (
                      <AlertCircle className="text-yellow-500" size={20} />
                    ) : (
                      <AlertCircle className="text-red-500" size={20} />
                    )}
                  </div>
                  <p className="text-muted font-medium text-lg">{item.value}</p>
                </div>
              ))}
            </div>

            {/* Recommendations */}
            <div className="glassmorphic p-8 rounded-3xl neumorphic-light">
              <h3 className="text-2xl font-black text-foreground mb-6">توصیات بهبود</h3>
              <ul className="space-y-3">
                {result.title.length === 0 && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">عنوان صفحه برای SEO اضافه کنید</span>
                  </li>
                )}
                {result.description.length === 0 && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">فراداده توضیحی اضافه کنید</span>
                  </li>
                )}
                {result.h1Count === 0 && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">حداقل یک عنوان H1 استفاده کنید</span>
                  </li>
                )}
                {result.h1Count > 1 && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">فقط یک H1 در صفحه استفاده کنید</span>
                  </li>
                )}
                {!result.hasSsl && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">گواهی SSL فعال کنید</span>
                  </li>
                )}
                {!result.isMobileReady && (
                  <li className="flex gap-3">
                    <span>💡</span>
                    <span className="text-muted font-medium">سایت را برای موبایل بهینه کنید</span>
                  </li>
                )}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
