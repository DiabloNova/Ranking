import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { AuthForm } from '@/components/auth-form'
import Link from 'next/link'

export const metadata = {
  title: 'ثبت‌نام - پیدا',
  description: 'ثبت‌نام حساب جدید',
}

export default async function SignUpPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect('/dashboard')

  return (
    <div className="min-h-screen bg-gradient-soft flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="glassmorphic p-8 rounded-3xl neumorphic-light">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-black text-foreground mb-2">ثبت‌نام</h1>
            <p className="text-muted font-medium">حساب جدید ایجاد کنید</p>
          </div>

          <AuthForm mode="sign-up" />

          <div className="mt-6 text-center">
            <p className="text-muted font-medium">
              قبلاً ثبت‌نام کردید؟{' '}
              <Link href="/sign-in" className="text-primary font-bold hover:underline">
                وارد شوید
              </Link>
            </p>
          </div>

          <div className="mt-4">
            <Link
              href="/"
              className="block text-center text-muted hover:text-primary transition-colors font-medium"
            >
              بازگشت به خانه
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
