'use client'

import Link from 'next/link'
import { ArrowLeft, Zap, BarChart3, Shield, Rocket } from 'lucide-react'
import { MotionBackground } from '@/components/motion-background'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Hero Section */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <MotionBackground />
        <div className="relative grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in z-10">
            <h1 className="text-5xl md:text-6xl font-black text-foreground leading-tight">
              سایت خود را به صدر <span className="text-highlight">نتایج گوگل</span> برسانید
            </h1>
            <p className="text-xl text-muted font-medium leading-relaxed">
              رنکینگ متخصصان بهینه‌سازی موتورهای جستجو. با استراتژی داده‌محور، تکنیک‌های روز‌شمار و گزارش‌های شفاف، ترافیک آلی سایت خود را افزایش دهید.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Link
                href="/analyzer"
                className="px-8 py-3 bg-primary text-white rounded-full font-bold hover:shadow-lg transition-all flex items-center gap-2"
              >
                <Zap size={20} />
                تحلیل رایگان
              </Link>
              <Link
                href="/about"
                className="px-8 py-3 neumorphic-light rounded-full font-bold transition-all flex items-center gap-2"
              >
                درباره ما
                <ArrowLeft size={20} />
              </Link>
            </div>
          </div>

          <div className="hidden md:block animate-slide-in">
            <div className="neumorphic-card p-12 text-center">
              <div className="text-6xl mb-4">📊</div>
              <p className="text-foreground font-bold">تجزیه و تحلیل جامع سایت</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black text-foreground mb-4">چرا رنکینگ را انتخاب کنید؟</h2>
          <p className="text-lg text-muted font-medium">بهترین ابزارها و خدمات برای افزایش رتبه‌بندی سایت شما</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: <BarChart3 size={32} />,
              title: 'تحلیل جامع رایگان',
              description: 'بررسی کامل سایت شامل فاکتورهای تکنیکی، محتوایی و بک‌لینک‌ها بدون هزینه',
            },
            {
              icon: <Shield size={32} />,
              title: 'امنیت درجه یک',
              description: 'تمام اطلاعات شما با رمزگذاری SSL و استانداردهای بین‌المللی محافظت می‌شود',
            },
            {
              icon: <Rocket size={32} />,
              title: 'نتایج سریع',
              description: 'افزایش ترافیک ارگانیک در ۹۰ روز یا پول شما را پس می‌دهیم',
            },
            {
              icon: <Zap size={32} />,
              title: 'سرعت بالا',
              description: 'تجزیه‌وتحلیل فوری و گزارش‌های به‌روز شده روزانه',
            },
            {
              icon: <BarChart3 size={32} />,
              title: 'گزارش‌های تفصیلی',
              description: 'داشبورد جامع با متریک‌های دقیق و توصیات قابل‌اجرا',
            },
            {
              icon: <Shield size={32} />,
              title: 'تیم متخصص ۲۴/۷',
              description: 'مشاورین SEO ما هر ساعت آماده کمک و راهنمایی هستند',
            },
          ].map((feature, i) => (
            <div
              key={i}
              className="neumorphic-card hover:scale-105 transition-transform cursor-pointer"
            >
              <div className="text-primary mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-foreground mb-2">{feature.title}</h3>
              <p className="text-muted font-medium text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="neumorphic-card text-center">
          <h2 className="text-4xl font-black text-foreground mb-4">آماده‌اید شروع کنید؟</h2>
          <p className="text-lg text-muted font-medium mb-8">
            ابزار رایگان ما را امتحان کنید و نتایج را از دست ندهید
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link
              href="/analyzer"
              className="px-8 py-3 bg-primary text-white rounded-full font-bold hover:shadow-lg transition-all"
            >
              تحلیل رایگان
            </Link>
            <Link
              href="/sign-up"
              className="px-8 py-3 neumorphic-light text-foreground rounded-full font-bold hover:shadow-xl transition-all"
            >
              ثبت‌نام کنید
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
