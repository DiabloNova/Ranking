import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { AuthForm } from '@/components/auth-form'
import Link from 'next/link'

export const metadata = {
  title: 'ورود - پیدا',
  description: 'وارد حساب کاربری خود شوید',
}

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect('/dashboard')

  return (
    <div className="min-h-screen bg-gradient-soft flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="glassmorphic p-8 rounded-3xl neumorphic-light">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-black text-foreground mb-2">ورود</h1>
            <p className="text-muted font-medium">به حساب خود وارد شوید</p>
          </div>

          <AuthForm mode="sign-in" />

          <div className="mt-6 text-center">
            <p className="text-muted font-medium">
              حساب ندارید؟{' '}
              <Link href="/sign-up" className="text-primary font-bold hover:underline">
                ثبت‌نام کنید
              </Link>
            </p>
          </div>

          <div className="mt-4">
            <Link
              href="/"
              className="block text-center text-muted hover:text-primary transition-colors font-medium"
            >
              بازگشت به خانه
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
